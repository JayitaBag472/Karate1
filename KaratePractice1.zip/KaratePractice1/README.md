# Karate1
