package features;

import com.intuit.karate.junit5.Karate;

public class TestRunner {
    
	  @Karate.Test
	    Karate getAPITest() {
	        return  Karate.run("getApi").relativeTo(getClass());
	    }  
	  @Karate.Test
	    Karate putAPITest() {
	        return  Karate.run("put").relativeTo(getClass());
	    }  
	  @Karate.Test
	    Karate postAPITest() {
	        return  Karate.run("post").relativeTo(getClass());
	      
   //   @Karate.Test
     //  Karate deleteAPITest() {
      //  return  Karate.run("deleteapi").relativeTo(getClass());
    }  

}